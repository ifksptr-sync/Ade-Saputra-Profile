(async function init() {
    if (document.getElementById("coretax-toolkit-panel")) return;
    function send(m) { return new Promise(r => chrome.runtime.sendMessage(m, r)); }

    const license = await send({ type: "GET_LICENSE_STATUS" });

    // ========================================================
    // LOCK SCREEN
    // ========================================================
    if (!license.valid) {
        const machineId = license.machineId || "-";
        const reason = license.reason || "License tidak valid.";
        const activated = license.activated;
        const expired = reason.toLowerCase().includes("kadaluarsa");

        const lock = document.createElement("div");
        lock.id = "coretax-toolkit-panel";
        lock.classList.add("ct-lock-mode");
        lock.innerHTML = `
            <div class="ct-lock-header" id="ct-lock-drag">
                <div class="ct-lock-header-left">
                    <div class="ct-lock-icon">[L]</div>
                    <div>
                        <strong>Coretax PDF Toolkit</strong>
                        <span>Extension Terkunci</span>
                    </div>
                </div>
                <div class="ct-header-buttons">
                    <button id="ct-lock-min" title="Minimize">-</button>
                    <button id="ct-lock-close" title="Tutup">x</button>
                </div>
            </div>
            <div class="ct-lock-body" id="ct-lock-body">
                <div class="ct-lock-alert ${expired ? 'ct-lock-warn' : 'ct-lock-err'}">
                    <span class="ct-lock-alert-icon">[!]</span>
                    <div>
                        <strong>${expired ? "License Kadaluarsa" : (activated ? "License Tidak Valid" : "Belum Ada License")}</strong>
                        <p>${reason}</p>
                    </div>
                </div>
                <div class="ct-lock-section">
                    <div class="ct-lock-section-title">
                        <span class="ct-lock-step">1</span>
                        Copy Machine ID kamu
                    </div>
                    <div class="ct-lock-mid">
                        <code id="ct-lock-mid">${machineId}</code>
                        <button id="ct-lock-copy-mid" class="ct-lock-copy-btn" title="Copy">[C]</button>
                    </div>
                    <div class="ct-lock-hint">Kirim Machine ID ini ke penjual untuk mendapat License Key.</div>
                </div>
                <div class="ct-lock-section">
                    <div class="ct-lock-section-title">
                        <span class="ct-lock-step">2</span>
                        Aktivasi License
                    </div>
                    <div class="ct-lock-instruction">
                        Klik icon <b>Coretax PDF Toolkit</b> di toolbar Chrome (kanan atas), paste License Key, klik <b>Activate</b>.
                    </div>
                    <button id="ct-lock-recheck" class="ct-lock-btn-primary">Cek Ulang License</button>
                </div>
                <div class="ct-lock-footer">
                    <div class="ct-lock-status" id="ct-lock-status">
                        <span class="ct-lock-dot"></span> Menunggu aktivasi...
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(lock);

        lock.querySelector("#ct-lock-copy-mid").addEventListener("click", async () => {
            try {
                await navigator.clipboard.writeText(machineId);
                const btn = lock.querySelector("#ct-lock-copy-mid");
                btn.textContent = "[OK]";
                btn.classList.add("ct-lock-copied");
                const status = lock.querySelector("#ct-lock-status");
                status.innerHTML = '<span class="ct-lock-dot ct-lock-dot-ok"></span> Machine ID ter-copy';
                setTimeout(() => { btn.textContent = "[C]"; btn.classList.remove("ct-lock-copied"); }, 1500);
            } catch (e) { alert("Gagal copy. Copy manual: " + machineId); }
        });

        lock.querySelector("#ct-lock-recheck").addEventListener("click", async () => {
            const status = lock.querySelector("#ct-lock-status");
            status.innerHTML = '<span class="ct-lock-dot ct-lock-dot-load"></span> Memeriksa...';
            const res = await send({ type: "GET_LICENSE_STATUS" });
            if (res.valid) {
                status.innerHTML = '<span class="ct-lock-dot ct-lock-dot-ok"></span> Valid! Reload...';
                setTimeout(() => location.reload(), 1200);
            } else {
                status.innerHTML = `<span class="ct-lock-dot ct-lock-dot-err"></span> ${res.reason || "Belum valid"}`;
            }
        });

        const dragEl = lock.querySelector("#ct-lock-drag");
        let dragState = null;
        dragEl.addEventListener("mousedown", (e) => {
            if (e.target.closest(".ct-header-buttons")) return;
            const rect = lock.getBoundingClientRect();
            dragState = { ox: e.clientX - rect.left, oy: e.clientY - rect.top };
            lock.style.right = "auto"; lock.style.bottom = "auto";
            document.addEventListener("mousemove", onDrag);
            document.addEventListener("mouseup", onDragEnd);
            e.preventDefault();
        });
        function onDrag(e) {
            if (!dragState) return;
            lock.style.left = Math.max(0, Math.min(e.clientX - dragState.ox, window.innerWidth - 80)) + "px";
            lock.style.top  = Math.max(0, Math.min(e.clientY - dragState.oy, window.innerHeight - 40)) + "px";
        }
        function onDragEnd() { dragState = null; document.removeEventListener("mousemove", onDrag); document.removeEventListener("mouseup", onDragEnd); }

        let minimizedLock = false;
        lock.querySelector("#ct-lock-min").addEventListener("click", () => {
            minimizedLock = !minimizedLock;
            lock.querySelector("#ct-lock-body").style.display = minimizedLock ? "none" : "";
            lock.querySelector("#ct-lock-min").textContent = minimizedLock ? "+" : "-";
        });
        lock.querySelector("#ct-lock-close").addEventListener("click", () => { lock.style.display = "none"; });

        const lockInterval = setInterval(async () => {
            if (lock.style.display === "none") return;
            const res = await send({ type: "GET_LICENSE_STATUS" });
            if (res.valid) {
                clearInterval(lockInterval);
                lock.querySelector("#ct-lock-status").innerHTML = '<span class="ct-lock-dot ct-lock-dot-ok"></span> Valid! Reload...';
                setTimeout(() => location.reload(), 800);
            }
        }, 5000);
        return;
    }

    const isTrialMode = (license.tier === "trial");
    if (isTrialMode) {
        await send({ type: "RESET_TRIAL_SESSION" });
    }

    const isWithholding = location.pathname.includes("/withholding-slips-portal/");
    const pageType = isWithholding ? "withholding" : "invoice";
    const TITLE = isWithholding ? "Coretax Bukti Potong" : "Coretax Faktur Pajak";
    const SUBTITLE = isWithholding ? "My Withholding Slips" : "Faktur Pajak Keluaran / Masukan";

    const panel = document.createElement("div");
    panel.id = "coretax-toolkit-panel";
    panel.innerHTML = `
        <div class="ct-header" id="ct-drag-handle">
            <div class="ct-title-wrap">
                <strong>${TITLE}</strong>
                <span>${SUBTITLE}</span>
            </div>
            <div class="ct-header-buttons">
                <button id="ct-minimize" title="Minimize">-</button>
                <button id="ct-maximize" title="Maximize">[]</button>
                <button id="ct-close" title="Tutup">x</button>
            </div>
        </div>
        <div class="ct-body" id="ct-body">
            <div class="ct-status" id="ct-status">Menunggu data...</div>
            <div class="ct-summary">
                <div><span>Total</span><strong id="ct-total">0</strong></div>
                <div><span>Ditampilkan</span><strong id="ct-shown">0</strong></div>
            </div>
            <div class="ct-actions">
                <button id="ct-refresh" class="ct-btn">Refresh</button>
                <button id="ct-all" class="ct-btn ct-primary">Download All</button>
                <button id="ct-stop" class="ct-btn ct-danger">Stop</button>
            </div>
            <div class="ct-progress"><div id="ct-progress-bar"></div></div>
            <div id="ct-progress-text" class="ct-progress-text"></div>
            <div id="ct-list"></div>
        </div>
        <div class="ct-resize-handle" id="ct-resize-handle"></div>
    `;
    document.body.appendChild(panel);

    const dragHandle = panel.querySelector("#ct-drag-handle");
    const resizeHandle = panel.querySelector("#ct-resize-handle");
    const bodyEl = panel.querySelector("#ct-body");
    const statusEl = panel.querySelector("#ct-status");
    const listEl = panel.querySelector("#ct-list");
    const progressBar = panel.querySelector("#ct-progress-bar");
    const progressText = panel.querySelector("#ct-progress-text");
    const totalEl = panel.querySelector("#ct-total");
    const shownEl = panel.querySelector("#ct-shown");

    // TRIAL MODE - badge + countdown + auto lock
    if (isTrialMode) {
        const trialInterval = setInterval(async () => {
            const panelEl = document.getElementById("coretax-toolkit-panel");
            if (!panelEl) return;
            const st = await send({ type: "GET_TRIAL_STATE" });
            if (!st) return;

            const statusBar = panelEl.querySelector("#ct-status");
            if (statusBar && !statusBar.dataset.trialLocked) {
                if (st.blocked) {
                    statusBar.innerHTML = '<span style="color:#b91c1c;font-weight:700;">[!] ' + st.blockReason + '</span>';
                } else {
                    const mm = String(Math.floor(st.remainingMs / 60000)).padStart(2, "0");
                    const ss = String(Math.floor((st.remainingMs % 60000) / 1000)).padStart(2, "0");
                    statusBar.innerHTML = '[TRIAL] ' + mm + ':' + ss + ' - Sisa: ' + st.remainingDownloads + '/5 PDF';
                }
            }

            if (st.blocked) {
                const bodyLock = panelEl.querySelector(".ct-body");
                if (bodyLock && !bodyLock.dataset.trialLocked) {
                    bodyLock.dataset.trialLocked = "1";
                    bodyLock.innerHTML = '<div style="padding:32px 24px;text-align:center;font-family:Arial,sans-serif;">' +
                        '<div style="font-size:44px;margin-bottom:12px;">[!]</div>' +
                        '<h3 style="margin:0 0 10px;color:#111827;font-size:16px;font-weight:900;">Sesi Trial Berakhir</h3>' +
                        '<p style="margin:0 0 18px;color:#6b7280;font-size:12px;line-height:1.6;max-width:300px;margin-left:auto;margin-right:auto;">' + st.blockReason + '</p>' +
                        '<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">' +
                        '<button onclick="location.reload()" style="padding:11px 20px;background:#111827;color:#fff;border:0;border-radius:10px;font-weight:800;font-size:12px;cursor:pointer;">Refresh Halaman</button>' +
                        '<a href="https://ifksptr-sync.github.io/Ade-Saputra-Profile/#contact" target="_blank" style="padding:11px 20px;background:#fff;color:#111827;border:1px solid #d1d5db;border-radius:10px;font-weight:800;font-size:12px;text-decoration:none;display:inline-flex;align-items:center;">Upgrade Full</a>' +
                        '</div></div>';
                }
            }
        }, 500);

        setTimeout(() => {
            const panelEl = document.getElementById("coretax-toolkit-panel");
            if (!panelEl) return;
            const titleWrap = panelEl.querySelector(".ct-title-wrap");
            if (titleWrap && !titleWrap.querySelector(".trial-badge")) {
                const badge = document.createElement("span");
                badge.className = "trial-badge";
                badge.style.cssText = "display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:999px;background:rgba(245,158,11,.2);color:#fbbf24;font-size:9px;font-weight:800;margin-top:6px;width:fit-content;border:1px solid rgba(245,158,11,.4);";
                badge.textContent = "TRIAL - 5 MENIT/SESI";
                titleWrap.appendChild(badge);
            }
        }, 500);
    }

    let dragState = null;
    dragHandle.addEventListener("mousedown", (e) => {
        if (e.target.closest(".ct-header-buttons")) return;
        const rect = panel.getBoundingClientRect();
        dragState = { ox: e.clientX - rect.left, oy: e.clientY - rect.top };
        panel.style.right = "auto"; panel.style.bottom = "auto";
        document.addEventListener("mousemove", onDragMove);
        document.addEventListener("mouseup", onDragEnd);
        e.preventDefault();
    });
    function onDragMove(e) {
        if (!dragState) return;
        panel.style.left = Math.max(0, Math.min(e.clientX - dragState.ox, window.innerWidth - 80)) + "px";
        panel.style.top  = Math.max(0, Math.min(e.clientY - dragState.oy, window.innerHeight - 40)) + "px";
    }
    function onDragEnd() { dragState = null; document.removeEventListener("mousemove", onDragMove); document.removeEventListener("mouseup", onDragEnd); }

    let resizeState = null;
    resizeHandle.addEventListener("mousedown", (e) => {
        const rect = panel.getBoundingClientRect();
        resizeState = { sx: e.clientX, sy: e.clientY, sw: rect.width, sh: rect.height };
        document.addEventListener("mousemove", onResizeMove);
        document.addEventListener("mouseup", onResizeEnd);
        e.preventDefault(); e.stopPropagation();
    });
    function onResizeMove(e) {
        if (!resizeState) return;
        panel.style.width = Math.max(360, resizeState.sw + (e.clientX - resizeState.sx)) + "px";
        panel.style.height = Math.max(300, resizeState.sh + (e.clientY - resizeState.sy)) + "px";
        panel.style.maxHeight = "none";
    }
    function onResizeEnd() { resizeState = null; document.removeEventListener("mousemove", onResizeMove); document.removeEventListener("mouseup", onResizeEnd); }

    let minimized = false, maximized = false;
    panel.querySelector("#ct-minimize").addEventListener("click", () => {
        minimized = !minimized;
        bodyEl.style.display = minimized ? "none" : "";
        resizeHandle.style.display = minimized ? "none" : "";
        panel.style.height = minimized ? "auto" : "";
        panel.querySelector("#ct-minimize").textContent = minimized ? "+" : "-";
    });
    panel.querySelector("#ct-maximize").addEventListener("click", () => {
        maximized = !maximized;
        if (maximized) {
            panel.dataset.prev = JSON.stringify({ l: panel.style.left, t: panel.style.top, w: panel.style.width, h: panel.style.height, r: panel.style.right });
            panel.style.left = "20px"; panel.style.top = "20px"; panel.style.right = "auto";
            panel.style.width = (window.innerWidth - 40) + "px";
            panel.style.height = (window.innerHeight - 40) + "px";
            panel.style.maxHeight = "none";
            panel.querySelector("#ct-maximize").textContent = "[X]";
        } else {
            try {
                const p = JSON.parse(panel.dataset.prev || "{}");
                panel.style.left = p.l || ""; panel.style.top = p.t || "";
                panel.style.width = p.w || "450px"; panel.style.height = p.h || "";
                panel.style.right = p.r || "20px";
                panel.style.maxHeight = "82vh";
            } catch {}
            panel.querySelector("#ct-maximize").textContent = "[]";
        }
    });
    panel.querySelector("#ct-close").addEventListener("click", () => { panel.style.display = "none"; });

    let rows = [];
    function setStatus(t) { statusEl.textContent = t; }
    function updateProgress(c, t) {
        const p = t ? Math.round((c / t) * 100) : 0;
        progressBar.style.width = `${p}%`;
        progressText.textContent = t ? `${c} / ${t} (${p}%)` : "";
    }
    function escapeHtml(v) {
        return String(v ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
    }
    function formatNumber(v) {
        const n = Number(v);
        return Number.isFinite(n) ? n.toLocaleString("id-ID") : "-";
    }
    function renderRows() {
        listEl.innerHTML = "";
        if (!rows.length) { listEl.innerHTML = `<div class="ct-empty">Tidak ada data.</div>`; return; }
        rows.forEach((row, index) => {
            const item = document.createElement("div");
            item.className = "ct-row";
            let primary, secondary, tertiary;
            if (pageType === "withholding") {
                primary = row.WithholdingSlipsNumber || "-";
                secondary = row.Name || "-";
                tertiary = `${row.TaxArticle || "-"} - ${row.WithholdingSlipsStatus || "-"}`;
            } else {
                primary = row.TaxInvoiceNumber || "-";
                secondary = row.BuyerTaxpayerNameClear || row.SellerTaxpayerName || row.BuyerName || "-";
                tertiary = `${row.TaxInvoiceStatus || "-"} - ${row.TaxInvoiceDate ? row.TaxInvoiceDate.substring(0,10) : "-"}`;
            }
            item.innerHTML = `<div class="ct-row-info"><strong>${escapeHtml(primary)}</strong><span>${escapeHtml(secondary)}</span><small>${escapeHtml(tertiary)}</small></div><button class="ct-download-one" data-index="${index}">PDF</button>`;
            listEl.appendChild(item);
        });
        panel.querySelectorAll(".ct-download-one").forEach(btn => {
            btn.addEventListener("click", async () => {
                const idx = Number(btn.dataset.index);
                const row = rows[idx];
                btn.disabled = true; btn.textContent = "...";
                const msgType = pageType === "withholding" ? "DOWNLOAD_WITHHOLDING_ONE" : "DOWNLOAD_INVOICE_ONE";
                const res = await send({ type: msgType, row });
                if (res.success) btn.textContent = "OK";
                else { btn.textContent = "ERR"; btn.title = res.error; }
                setTimeout(() => { btn.disabled = false; btn.textContent = res.success ? "OK" : "ERR"; }, 1500);
            });
        });
    }
    async function loadData() {
        setStatus("Mengambil data...");
        const msgType = pageType === "withholding" ? "GET_WITHHOLDING_LIST" : "GET_INVOICE_LIST";
        const res = await send({ type: msgType });
        if (!res || !res.success) { setStatus(res?.error || "Gagal."); return; }
        rows = res.data?.Payload?.Data || [];
        const total = res.data?.Payload?.TotalRecords ?? rows.length;
        totalEl.textContent = formatNumber(total);
        shownEl.textContent = formatNumber(rows.length);
        if (pageType === "invoice" && res.mode) {
            setStatus(`${rows.length} data - ${res.mode === "input" ? "Faktur Masukan" : "Faktur Keluaran"} - Total ${total}`);
        } else setStatus(`${rows.length} data | Total ${total}`);
        renderRows();
    }
    async function loadAllData() {
        setStatus("Mengambil seluruh data...");
        const msgType = pageType === "withholding" ? "GET_WITHHOLDING_ALL" : "GET_INVOICE_ALL";
        const res = await send({ type: msgType });
        if (!res || !res.success) { setStatus(res?.error || "Gagal."); return null; }
        rows = res.rows || [];
        totalEl.textContent = formatNumber(res.totalRecords);
        shownEl.textContent = formatNumber(rows.length);
        setStatus(`${rows.length} data dimuat`);
        renderRows();
        return rows;
    }
    async function downloadAllHandler() {
        const all = await loadAllData();
        if (!all || !all.length) { setStatus("Tidak ada data."); return; }
        setStatus(`Memulai Download All: ${all.length} file...`);
        updateProgress(0, all.length);
        const msgType = pageType === "withholding" ? "DOWNLOAD_WITHHOLDING_ALL" : "DOWNLOAD_INVOICE_ALL";
        const res = await send({ type: msgType, rows: all });
        if (!res || !res.success) { setStatus(res?.error || "Download All gagal."); return; }
        const r = res.result;
        updateProgress(r.completed, r.total);
        setStatus(`Selesai | OK ${r.completed} | ERR ${r.failed}`);
    }
    panel.querySelector("#ct-refresh").addEventListener("click", loadData);
    panel.querySelector("#ct-all").addEventListener("click", downloadAllHandler);
    panel.querySelector("#ct-stop").addEventListener("click", async () => {
        await send({ type: "STOP_DOWNLOAD" });
        setStatus("Stop diminta...");
    });
    loadData();
})();